export default function Page() {
  return (
    <div className="min-h-screen bg-[#09090b] text-[#fafafa] flex items-center justify-center p-8">
      <div className="max-w-2xl w-full">
        <div className="flex items-center gap-3 mb-8">
          <div className="text-[#3b82f6]">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
              <rect x="3" y="3" width="7" height="7" rx="1" fill="currentColor" />
              <rect x="14" y="3" width="7" height="7" rx="1" fill="currentColor" opacity="0.5" />
              <rect x="3" y="14" width="7" height="7" rx="1" fill="currentColor" opacity="0.5" />
              <rect x="14" y="14" width="7" height="7" rx="1" fill="currentColor" />
            </svg>
          </div>
          <h1 className="text-3xl font-semibold tracking-tight">
            <span className="text-[#3b82f6]">My</span>ChessLeague
          </h1>
        </div>

        <div className="bg-[#131316] border border-[#27272a] rounded-xl p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              className="text-[#f59e0b]"
            >
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            Vite Project
          </h2>
          <p className="text-[#a1a1aa] text-sm leading-relaxed mb-4">
            이 프로젝트는 Vite 기반 React 앱으로, v0 프리뷰에서 직접 실행되지 않습니다. 로컬에서 실행하려면 아래
            명령어를 사용하세요.
          </p>

          <div className="bg-[#09090b] rounded-lg p-4 font-mono text-sm">
            <div className="text-[#71717a] mb-2"># Frontend 실행</div>
            <div className="text-[#22c55e]">cd frontend</div>
            <div className="text-[#22c55e]">npm install</div>
            <div className="text-[#22c55e]">npm run dev</div>
          </div>
        </div>

        <div className="bg-[#131316] border border-[#27272a] rounded-xl p-6">
          <h2 className="text-lg font-semibold mb-4">주요 기능</h2>
          <ul className="space-y-3">
            {[
              { icon: "👥", title: "사용자 관리", desc: "ELO 레이팅 기반 사용자 및 순위 관리" },
              { icon: "🏆", title: "리그 & 토너먼트", desc: "Swiss / Round Robin 리그, Double Elimination 토너먼트" },
              { icon: "♟️", title: "경기 기록", desc: "Chess.com 연동 및 수동 경기 기록" },
              { icon: "📊", title: "게임 분석", desc: "Stockfish 엔진을 활용한 실시간 게임 분석" },
            ].map((feature, i) => (
              <li key={i} className="flex items-start gap-3">
                <span className="text-xl">{feature.icon}</span>
                <div>
                  <div className="font-medium text-sm">{feature.title}</div>
                  <div className="text-[#71717a] text-sm">{feature.desc}</div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-6 text-center text-[#52525b] text-sm">디자인이 모던 다크 테마로 업데이트되었습니다.</div>
      </div>
    </div>
  )
}
